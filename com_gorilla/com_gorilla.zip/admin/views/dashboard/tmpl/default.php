<?php

/**
 * Gorilla Document Manager
 *
 * @author     Rodrigo Petters
 * @copyright  2013-2014 SOHO Prospecting LLC (California - USA)
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link https://www.sohoprospecting.com
 *
 * Try not. Do or do not. There is no try.
 */

// No direct access to this file
defined('_JEXEC') or die;
?>

<div class="cpanel">
	<span><?php echo JText::_('COM_GORILLA_DESCRIPTION'); ?></span>
</div>